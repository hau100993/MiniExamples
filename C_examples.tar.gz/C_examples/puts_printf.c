
#include <stdio.h>
#include <string.h>


void main () {
char * msg ;
msg = " ABCD" ;

 puts (  " Puts   :  %s  \n ", msg );
 printf (" Printf :  %s  \n ", msg );

}
