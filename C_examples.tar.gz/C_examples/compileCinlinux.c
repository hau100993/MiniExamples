#include <stdio.h>
#define HELLO "Hello linux, I am C \n  " 
 int main () {
 printf (HELLO);
 return 0;
}

